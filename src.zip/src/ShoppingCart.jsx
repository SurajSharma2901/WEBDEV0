import { useState } from "react";

function ShoppingCart() {
    const products = [
        { id: 1, name: "Italian Pizza", price: 9, image: "public/p3.jpg" },
        { id: 2, name: "Neapolitan Pizza", price: 5, image: "public/p4.jpg" },
        { id: 3, name: "Pepperoni Pizza", price: 3, image: "public/p10.jpg" },
    ];

    const [cart, setCart] = useState([]);

    const addToCart = (product) => {
        setCart((prevCart) => {
            const existingItem = prevCart.find(item => item.id === product.id);
            if (existingItem) {
                return prevCart.map(item => 
                    item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
                );
            }
            return [...prevCart, { ...product, quantity: 1 }];
        });
    };

    const removeFromCart = (id) => {
        setCart((prevCart) => prevCart.filter(item => item.id !== id));
    };

    const getTotal = () => {
        return cart.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2);
    };

    return (
        <div style={{ padding: "20px", fontFamily: "Arial, sans-serif" }}>
            <h2>Products</h2>
            <ul>
                {products.map((product) => (
                    <li key={product.id}>
                        <img src={product.image} alt={product.name} style={{ width: "50px", marginRight: "10px" }} />
                        {product.name} - ${product.price}
                        <button onClick={() => addToCart(product)} style={{ marginLeft: "10px" }}>
                            Add to Cart
                        </button>
                    </li>
                ))}
            </ul>

            <h2>Shopping Cart</h2>
            {cart.length === 0 ? (
                <p>Your cart is empty</p>
            ) : (
                <ul>
                    {cart.map((item) => (
                        <li key={item.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "300px", borderBottom: "1px solid #ccc", padding: "5px 0" }}>
                            <img src={item.image} alt={item.name} style={{ width: "50px", marginRight: "10px" }} />
                            <span>{item.name} - ${item.price} x {item.quantity} = ${(item.price * item.quantity).toFixed(2)}</span>
                            <button onClick={() => removeFromCart(item.id)} style={{ marginLeft: "10px" }}>
                                Remove
                            </button>
                        </li>
                    ))}
                </ul>
            )}
            <h3>Total: ${getTotal()}</h3>
        </div>
    );
}

export default ShoppingCart;
