import React from 'react';
function Hero(){
    return (
        <section id="hero">
            <div className="content1">
                <h4>A Slice of Heaven, Delivered to You!</h4>
                <h3>A Taste of Italy</h3>
                <h1>Tradition in Every Bite...</h1>
                <p>Serving love with Every Slice.<br></br>HandCrafted Pizzas, Inspired by Tradition. </p>
                <h3>Get Up to 50% off!</h3><h6>On your 1st order</h6>
                <button>Order Now</button>
            </div>
        </section>
    );
}

export default Hero
