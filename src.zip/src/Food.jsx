import React from 'react'
import img1 from './assets/Slider/1st.jpg'
function Food(){
    return (
        
        <div className="Card">
                <img src={img1} alt="img1" className="Card-image" />
                <div className="Card-content">
                    <h2 className="Card-title">Margherita</h2>
                    <p className="Card-text">This is a sample text</p>
                    <h4>$5</h4>
                </div> 
        </div>
        
    );
}
 
export default Food