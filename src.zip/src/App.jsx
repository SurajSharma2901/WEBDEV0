
import {useState} from'react';
import Header from './Header.jsx';
import User from './User.jsx';
import Footer from './Footer.jsx';
import Food from './Food';

import Hero from './Hero.jsx';
// import Slider from'./Slider.jsx';
import ShoppingCart from './ShoppingCart.jsx';
function App() {
  return (
    <>  
    <User/>
    <Header/>
    <Hero/>
    <Food/>
    <ShoppingCart/>
    <Footer/>
    </>
  );
}

export default App
