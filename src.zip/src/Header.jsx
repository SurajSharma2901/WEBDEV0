import React from'react';

function Header(){
    return(
    <section id="header">

      <h1 class='Domian'>SignorMargerita</h1>
      <div>
        <ul id = 'navbar'>
          <li><a class='active' href="index.html">Home</a></li>
          <li><a href="shop.html">Shop</a></li>
          <li><a href="customize.html">Customize</a></li>
          <li><a href="about.html">About</a></li>
          <li><a href="contact.html">Contact</a></li>
          <li><div id="cart"><a href="cart.html"><i class="fa-solid fa-cart-shopping"></i></a></div></li>
          <li><a href="user.html"><i class="fa-solid fa-user"></i></a></li>
        </ul>
      </div>
      
    </section>
    );
}

export default Header